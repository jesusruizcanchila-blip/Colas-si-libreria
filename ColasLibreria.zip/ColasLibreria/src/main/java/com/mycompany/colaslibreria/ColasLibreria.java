/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.colaslibreria;


 import java.util.ArrayDeque;
 import java.util.Queue;
 import java.util.Deque;
 import java.util.PriorityQueue;
  
public class ColasLibreria {

    public static void main(String[] args) {
        System.out.println("Ejercicio colas con libreria de java\n");
        Colasimple();
        ColaCircular();
        ColaPrioridad();
        ColasDoble();
    }
    
    static void Colasimple(){
       System.out.println("Ejercicio colas SImple:primero en llegar primer en salir");
        
       Queue<String> java = new ArrayDeque<>();
       java.offer("Ana");
       java.offer("Viviana");
       java.offer("Leiner");
         System.out.println("Java : " + java.poll() + ", " + java.poll()+ "\n");
       
       }
    static void ColaCircular(){
       System.out.println("Ejercicio colas SImple:primero en llegar primer en salir");
        
       Queue<String> java = new ArrayDeque<>();
       java.offer("Ana");
       java.offer("Viviana");
       java.offer("Leiner");
       System.out.println("Sale : " + java.poll());
       java.offer("Fabio");
       System.out.println("Java : " + java.poll() + ", " + java.poll()+ ", " + java.poll() + "\n");
       
       
       }
     static void ColaPrioridad(){
       System.out.println("Ejercicio colas Prioridad:el menor numero de atiende primero");
        
       Queue<Integer> java = new PriorityQueue<>();
       java.offer(5);
       java.offer(2);
       java.offer(3);
       
       System.out.println("Java : " + java.poll() + ", " + java.poll()+ ", " + java.poll() + "\n");
       
       
       }
     static void ColasDoble(){
       System.out.println("ColaDoble(DEQUE):permite usar ambos extremos");
        
       Deque<String> java = new ArrayDeque<>();
       java.offerLast("Ana");
       java.offerLast("Viviana");
       java.offerFirst("Leiner");
       
       System.out.println("Java : Sale del inicio" + java.pollFirst() + ",sale del final " + java.pollLast());
       
       
       }
  
}
